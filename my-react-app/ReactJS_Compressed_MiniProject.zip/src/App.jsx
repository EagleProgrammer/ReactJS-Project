import React from 'react';
import Forms from './forms.jsx'
function App() {
  return (
    <div>  
      <Forms></Forms>
    </div>
  );
}

export default App;